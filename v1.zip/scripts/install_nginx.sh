#!/bin/bash
yum update -y
yum install -y nginx