#!/bin/bash
systemctl start nginx
systemctl enable nginx