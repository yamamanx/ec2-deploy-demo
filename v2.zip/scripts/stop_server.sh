#!/bin/bash
systemctl stop nginx