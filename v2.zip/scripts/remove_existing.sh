#!/bin/bash
rm -f /usr/share/nginx/html/index.html